namespace TodoApi.Models
{
    public class TodoItem
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string IsComplete { get; set; }
        // In dieser Klasse kommt eine Neue Property dazu... Person
    }
}