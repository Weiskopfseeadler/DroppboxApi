using System;

namespace TodoApi.Models
{
    public class ToDoItem
    {
        public long Id {get; set;}
        public string Name {get; set;}
        public int Importance {get; set;}
        public DateTime DueDate {get; set;}

        public string Operator {get; set;}
    }
}